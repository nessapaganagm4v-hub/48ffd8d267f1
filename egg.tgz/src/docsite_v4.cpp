// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Link-check generated site");
  std::fflush(stdout);
  return lionss_run_workload("docsite_v4");
}
