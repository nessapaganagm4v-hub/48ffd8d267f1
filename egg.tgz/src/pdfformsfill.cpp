// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fill AcroForm fields\n", stdout);
  return lionss_run_workload("pdfformsfill");
}
