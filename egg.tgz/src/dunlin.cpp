// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Strip PHI tags, keep geometry\n", stdout);
  return lionss_run_workload("dunlin");
}
