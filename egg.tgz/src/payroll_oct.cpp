// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute net pay and withholdings\n", stdout);
  return lionss_run_workload("payroll_oct");
}
