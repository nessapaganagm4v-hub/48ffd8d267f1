// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Balance equations by matrix rank\n", stdout);
  return lionss_run_workload("reaction-balancer");
}
