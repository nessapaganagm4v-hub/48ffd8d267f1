// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fuzz JSON parser, 1 h"); }
int main(){
  announce();
  return lionss_run_workload("fjord");
}
