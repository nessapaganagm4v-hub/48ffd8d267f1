// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve 1000 puzzles with DLX"); }
int main(){
  announce();
  return lionss_run_workload("sudoku_dlx");
}
