// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Transcribe with timestamps"); }
int main(){
  announce();
  return lionss_run_workload("podcast-stt");
}
