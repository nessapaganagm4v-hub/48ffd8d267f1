// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode 4 parity, lose 3, recover"); }
int main(){
  announce();
  return lionss_run_workload("erasure104");
}
