// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate EAN-13 checksums\n", stdout);
  return lionss_run_workload("barcode-verify");
}
