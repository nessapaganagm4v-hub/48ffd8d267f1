// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Per-unit assessment"); }
int main(){
  announce();
  return lionss_run_workload("hoa-budget");
}
