// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Swarm risk from weight drop"); }
int main(){
  announce();
  return lionss_run_workload("hiveMonitor");
}
