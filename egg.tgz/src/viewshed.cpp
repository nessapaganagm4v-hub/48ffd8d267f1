// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Viewshed from tower, 10 km");
  std::fflush(stdout);
  return lionss_run_workload("viewshed");
}
