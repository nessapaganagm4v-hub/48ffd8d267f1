// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Expected-information first guess"); }
int main(){
  announce();
  return lionss_run_workload("wordleSolver");
}
