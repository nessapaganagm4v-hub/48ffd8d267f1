# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(reaction-balancer src/reaction-balancer.cpp)
set_property(TARGET reaction-balancer PROPERTY CXX_STANDARD 11)
target_link_libraries(reaction-balancer lionss pthread)

add_executable(loomsong src/loomsong.cpp)
set_property(TARGET loomsong PROPERTY CXX_STANDARD 11)
target_link_libraries(loomsong lionss pthread)

add_executable(hoa-budget src/hoa-budget.cpp)
set_property(TARGET hoa-budget PROPERTY CXX_STANDARD 11)
target_link_libraries(hoa-budget lionss pthread)

add_executable(lupine src/lupine.cpp)
set_property(TARGET lupine PROPERTY CXX_STANDARD 11)
target_link_libraries(lupine lionss pthread)

add_executable(pagecachesim src/pagecachesim.cpp)
set_property(TARGET pagecachesim PROPERTY CXX_STANDARD 11)
target_link_libraries(pagecachesim lionss pthread)

add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(barcode-verify src/barcode-verify.cpp)
set_property(TARGET barcode-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(barcode-verify lionss pthread)

add_executable(XfmrLoading src/XfmrLoading.cpp)
set_property(TARGET XfmrLoading PROPERTY CXX_STANDARD 11)
target_link_libraries(XfmrLoading lionss pthread)

add_executable(sudoku_dlx src/sudoku_dlx.cpp)
set_property(TARGET sudoku_dlx PROPERTY CXX_STANDARD 11)
target_link_libraries(sudoku_dlx lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(viewshed src/viewshed.cpp)
set_property(TARGET viewshed PROPERTY CXX_STANDARD 11)
target_link_libraries(viewshed lionss pthread)

add_executable(cite_check src/cite_check.cpp)
set_property(TARGET cite_check PROPERTY CXX_STANDARD 11)
target_link_libraries(cite_check lionss pthread)

add_executable(payroll_oct src/payroll_oct.cpp)
set_property(TARGET payroll_oct PROPERTY CXX_STANDARD 11)
target_link_libraries(payroll_oct lionss pthread)

add_executable(shopSearch src/shopSearch.cpp)
set_property(TARGET shopSearch PROPERTY CXX_STANDARD 11)
target_link_libraries(shopSearch lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(sentiment-reviews src/sentiment-reviews.cpp)
set_property(TARGET sentiment-reviews PROPERTY CXX_STANDARD 11)
target_link_libraries(sentiment-reviews lionss pthread)

add_executable(docsite_v4 src/docsite_v4.cpp)
set_property(TARGET docsite_v4 PROPERTY CXX_STANDARD 11)
target_link_libraries(docsite_v4 lionss pthread)

add_executable(ticketgate src/ticketgate.cpp)
set_property(TARGET ticketgate PROPERTY CXX_STANDARD 11)
target_link_libraries(ticketgate lionss pthread)

add_executable(tfPlanDry src/tfPlanDry.cpp)
set_property(TARGET tfPlanDry PROPERTY CXX_STANDARD 11)
target_link_libraries(tfPlanDry lionss pthread)

add_executable(tidewatch src/tidewatch.cpp)
set_property(TARGET tidewatch PROPERTY CXX_STANDARD 11)
target_link_libraries(tidewatch lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(dunlin src/dunlin.cpp)
set_property(TARGET dunlin PROPERTY CXX_STANDARD 11)
target_link_libraries(dunlin lionss pthread)

add_executable(usbeamform src/usbeamform.cpp)
set_property(TARGET usbeamform PROPERTY CXX_STANDARD 11)
target_link_libraries(usbeamform lionss pthread)

add_executable(erasure104 src/erasure104.cpp)
set_property(TARGET erasure104 PROPERTY CXX_STANDARD 11)
target_link_libraries(erasure104 lionss pthread)

add_executable(pdfformsfill src/pdfformsfill.cpp)
set_property(TARGET pdfformsfill PROPERTY CXX_STANDARD 11)
target_link_libraries(pdfformsfill lionss pthread)

add_executable(mdns-browse src/mdns-browse.cpp)
set_property(TARGET mdns-browse PROPERTY CXX_STANDARD 11)
target_link_libraries(mdns-browse lionss pthread)

add_executable(wordleSolver src/wordleSolver.cpp)
set_property(TARGET wordleSolver PROPERTY CXX_STANDARD 11)
target_link_libraries(wordleSolver lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(demandFcWeekly src/demandFcWeekly.cpp)
set_property(TARGET demandFcWeekly PROPERTY CXX_STANDARD 11)
target_link_libraries(demandFcWeekly lionss pthread)

add_executable(podcast-stt src/podcast-stt.cpp)
set_property(TARGET podcast-stt PROPERTY CXX_STANDARD 11)
target_link_libraries(podcast-stt lionss pthread)

